import json
import os
import sys
import urllib.request
import tarfile

def _debug(msg: str):
    print(msg, file=sys.stderr)

def _get(url: str, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    return urllib.request.urlopen(req)

def _get_json(url: str, headers=None):
    with _get(url, headers) as resp:
        return json.load(resp)

def _auth(repo: str):
    url = (
        f"https://auth.docker.io/token"
        f"?service=registry.docker.io&scope=repository:{repo}:pull"
    )
    return _get_json(url)["token"]

def _authorization_header(token: str):
    return {"Authorization": f"Bearer {token}"}

def _list_layers(repo: str, tag: str, token: str):
    url = f"https://registry-1.docker.io/v2/{repo}/manifests/{tag}"
    headers = {
        "Accept": "application/vnd.docker.distribution.manifest.v2+json",
        **_authorization_header(token),
    }
    manifest = _get_json(url, headers)

    # v2 schema 2
    if manifest.get("schemaVersion") == 2 and "layers" in manifest:
        return [layer["digest"] for layer in manifest["layers"]]

    # multi-arch manifest list
    if "manifests" in manifest:
        for m in manifest["manifests"]:
            plat = m.get("platform", {})
            if plat.get("architecture") == "amd64" and plat.get("os") == "linux":
                digest = m["digest"]
                sub = _get_json(
                    f"https://registry-1.docker.io/v2/{repo}/manifests/{digest}",
                    headers=headers
                )
                return [ly["digest"] for ly in sub.get("layers", [])]
        raise RuntimeError("no amd64/linux manifest found")

    # legacy schema1
    if "fsLayers" in manifest:
        return [layer["blobSum"] for layer in manifest["fsLayers"]]

    raise RuntimeError("unknown manifest format")

def _download_layer(repo: str, digest: str, token: str, layers_dir="layers"):
    safe_repo = repo.replace("/", "_")
    path = os.path.join(layers_dir, safe_repo, digest)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        _debug(f"skip {repo}:{digest}")
        return path

    _debug(f"downloading {repo}:{digest}")
    url = f"https://registry-1.docker.io/v2/{repo}/blobs/{digest}"
    with _get(url, headers=_authorization_header(token)) as resp:
        data = resp.read()
    with open(path, "wb") as f:
        f.write(data)
    return path

def pull(image: str, root_path: str):
    # parse image[:tag]
    if ":" in image:
        repo, tag = image.rsplit(":", 1)
    else:
        repo, tag = image, "latest"

    # official images live under "library/"
    if "/" not in repo:
        repo = f"library/{repo}"

    token   = _auth(repo)
    digests = _list_layers(repo, tag, token)

    for d in digests:
        layer_file = _download_layer(repo, d, token)
        with tarfile.open(layer_file, mode="r:*") as tar:
            tar.extractall(root_path)
