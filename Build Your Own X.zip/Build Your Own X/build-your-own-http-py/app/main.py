#!/usr/bin/env python3
"""
Build Your Own HTTP Server (Python)

Features implemented:
- Bind to a port
- Respond with 200
- Extract URL path
- Respond with body
- Read headers
- Concurrent connections (fork per client)
- Return a file
- Read request body (POST)
- HTTP Compression: gzip and deflate
- Persistent connections (keep-alive)
- Connection closure
"""
import os
import sys
import socket
import gzip as _gzip
import zlib as _zlib
import urllib.parse
import signal

STATUS_PHRASES = {
    200: "OK",
    201: "Created",
    400: "Bad Request",
    403: "Forbidden",
    404: "Not Found",
    405: "Method Not Allowed",
    500: "Internal Server Error",
}


COMPRESSORS = {
    "gzip": (_gzip.compress, "gzip"),
    "deflate": (_zlib.compress, "deflate"),
}


def send_response(conn, version, status, headers, body, method):
    """Write status line, headers, and body (unless HEAD) to conn."""
    phrase = STATUS_PHRASES.get(status, "")
    conn.write(f"{version} {status} {phrase}\r\n".encode("ascii"))
    # Default headers
    hdrs = {**headers}
    hdrs.setdefault("Content-Length", str(len(body) if body else 0))
    hdrs.setdefault("Server", "CodecraftersHTTP/0.1")
    # Write headers
    for k, v in hdrs.items():
        conn.write(f"{k}: {v}\r\n".encode("ascii"))
    conn.write(b"\r\n")
    # Body
    if method != "HEAD" and body:
        conn.write(body)


def handle_connection(client_sock):
    """Handle multiple HTTP requests on a single connection."""
    conn = client_sock.makefile("rwb", buffering=0)
    try:
        while True:
            # Read request line
            line = conn.readline().decode("ascii", errors="ignore")
            if not line:
                break  # client closed
            request_line = line.rstrip("\r\n")
            parts = request_line.split(" ")
            if len(parts) != 3:
                send_response(conn, "HTTP/1.1", 400, {"Content-Type": "text/plain"}, b"Bad Request\n", "GET")
                break
            method, raw_path, version = parts

            # Validate method & version
            if version not in ("HTTP/1.1", "HTTP/1.0"):
                send_response(conn, version, 505, {"Content-Type": "text/plain"}, b"HTTP Version Not Supported\n", method)
                break
            if method not in ("GET", "HEAD", "POST"):
                send_response(conn, version, 405, {"Allow": "GET, HEAD, POST", "Content-Type": "text/plain"}, b"Method Not Allowed\n", method)
                break

            # Read headers
            headers = {}
            while True:
                h = conn.readline().decode("ascii", errors="ignore").rstrip("\r\n")
                if not h:
                    break
                if ": " in h:
                    key, val = h.split(": ", 1)
                    headers[key.lower()] = val

            # Read body if POST
            body = b""
            if method == "POST":
                length = int(headers.get("content-length", "0"))
                if length > 0:
                    body = conn.read(length)

            # Route
            path = urllib.parse.unquote(raw_path.split("?", 1)[0])
            status = 404
            resp_headers = {}
            resp_body = b""

            if path == "/":
                entries = os.listdir(".")
                resp_body = "\n".join(entries).encode("utf-8")
                resp_headers["Content-Type"] = "text/plain; charset=utf-8"
                status = 200

            elif path.startswith("/echo/"):
                msg = path[len("/echo/"):]
                resp_body = msg.encode("utf-8")
                resp_headers["Content-Type"] = "text/plain; charset=utf-8"
                status = 200

            elif path == "/user-agent":
                ua = headers.get("user-agent", "")
                resp_body = ua.encode("utf-8")
                resp_headers["Content-Type"] = "text/plain; charset=utf-8"
                status = 200

            elif path.startswith("/files/"):
                rel = os.path.normpath(path[len("/files/"):])
                # Prevent directory traversal
                if rel.startswith(".."):
                    status = 403
                    resp_body = b"Forbidden\n"
                    resp_headers["Content-Type"] = "text/plain"
                else:
                    if method == "POST":
                        parent = os.path.dirname(rel)
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        with open(rel, "wb") as f:
                            f.write(body)
                        status = 201
                        resp_body = b""
                    else:
                        if os.path.isfile(rel):
                            with open(rel, "rb") as f:
                                resp_body = f.read()
                            ext = os.path.splitext(rel)[1].lower()
                            ctype = {
                                ".html": "text/html; charset=utf-8",
                                ".htm": "text/html; charset=utf-8",
                                ".txt": "text/plain; charset=utf-8",
                                ".jpg": "image/jpeg",
                                ".jpeg": "image/jpeg",
                                ".png": "image/png",
                            }.get(ext, "application/octet-stream")
                            resp_headers["Content-Type"] = ctype
                            status = 200
                        else:
                            status = 404
                            resp_body = b"Not Found\n"
                            resp_headers["Content-Type"] = "text/plain"
            else:
                status = 404
                resp_body = b"Not Found\n"
                resp_headers["Content-Type"] = "text/plain"

            # Compression
            ae = headers.get("accept-encoding", "")
            compressor = None
            for enc in [x.strip() for x in ae.split(",")]:
                if enc in COMPRESSORS:
                    compressor, enc_name = COMPRESSORS[enc]
                    break
            if compressor and resp_body:
                resp_body = compressor(resp_body)
                resp_headers["Content-Encoding"] = enc_name

            # Connection: keep-alive or close
            conn_hdr = headers.get("connection", "").lower()
            if version == "HTTP/1.1":
                keep_alive = (conn_hdr != "close")
            else:  # HTTP/1.0
                keep_alive = (conn_hdr == "keep-alive")
            resp_headers["Connection"] = "keep-alive" if keep_alive else "close"

            # Send it
            send_response(conn, version, status, resp_headers, resp_body, method)

            if not keep_alive:
                break

    except Exception:
        try:
            send_response(conn, "HTTP/1.1", 500, {"Content-Type": "text/plain"}, b"Internal Server Error\n", "GET")
        except Exception:
            pass
    finally:
        try: conn.close()
        except: pass
        try: client_sock.close()
        except: pass
        os._exit(0)


def main():
    port = 4221
    directory = None
    if len(sys.argv) >= 2:
        port = int(sys.argv[1])
    if len(sys.argv) >= 3:
        directory = sys.argv[2]
    if directory:
        os.chdir(directory)

    # reap children
    signal.signal(signal.SIGCHLD, signal.SIG_IGN)

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("0.0.0.0", port))
        server.listen()

        print(f"Serving HTTP on port {port} (dir={os.getcwd()})")

        while True:
            client_sock, addr = server.accept()
            pid = os.fork()
            if pid:
                client_sock.close()
            else:
                server.close()
                handle_connection(client_sock)


if __name__ == "__main__":
    main()
