#!/usr/bin/env python3
import abc
import dataclasses
import enum
import sys
import typing


class CharacterClass(enum.Enum):
    DIGITS = "d"
    WORDS = "w"

    def test(self, character: str) -> bool:
        c = ord(character)
        if self is CharacterClass.DIGITS:
            return ord('0') <= c <= ord('9')
        elif self is CharacterClass.WORDS:
            return (
                ord('0') <= c <= ord('9')
                or ord('A') <= c <= ord('Z')
                or ord('a') <= c <= ord('z')
                or c == ord('_')
            )
        else:
            raise RuntimeError(f"unknown enum: {self}")

    @staticmethod
    def of(character: str) -> "CharacterClass":
        for klass in CharacterClass:
            if klass.value == character:
                return klass
        raise RuntimeError(f"unknown CharacterClass: {character}")


@dataclasses.dataclass
class Consumer:
    input: str
    index: int = 0
    max: int = -1
    marks: typing.List[typing.Tuple[int, int]] = dataclasses.field(default_factory=list)

    def __post_init__(self):
        self.max = len(self.input)

    def next(self) -> str:
        if self.end:
            return "\0"
        ch = self.input[self.index]
        self.index += 1
        return ch

    def current(self) -> str:
        return "\0" if self.end else self.input[self.index]

    def peek(self) -> str:
        return (
            "\0"
            if self.index + 1 >= self.max
            else self.input[self.index + 1]
        )

    def mark(self):
        self.marks.append((self.index, self.max))

    def pop(self):
        if not self.marks:
            raise ValueError("pop stack empty")
        self.marks.pop()

    def reset(self):
        if not self.marks:
            raise ValueError("reset stack empty")
        i, m = self.marks.pop()
        self.index, self.max = i, m

    def slice(self, start: int) -> str:
        return self.input[start:self.index]

    @property
    def start(self) -> bool:
        return self.index == 0

    @property
    def end(self) -> bool:
        return self.index >= self.max

    def __str__(self):
        return f"Consumer({self.input!r}[{self.index}:{self.max}])"


@dataclasses.dataclass(kw_only=True)
class Node(abc.ABC):
    name: str = "unnamed"
    def match(self, input: Consumer) -> bool:
        raise NotImplementedError()


@dataclasses.dataclass(kw_only=True)
class PredicateNode(Node):
    def test(self, input: Consumer) -> bool:
        return True

    def match(self, input: Consumer) -> bool:
        input.mark()
        if self.test(input):
            input.pop()
            return True
        input.reset()
        return False


@dataclasses.dataclass(kw_only=True)
class Wildcard(PredicateNode):
    def test(self, input: Consumer) -> bool:
        return input.next() != "\0"


@dataclasses.dataclass(kw_only=True)
class Literal(PredicateNode):
    value: str

    def test(self, input: Consumer) -> bool:
        for ch in self.value:
            if input.next() != ch:
                return False
        return True


@dataclasses.dataclass(kw_only=True)
class Range(PredicateNode):
    character_class: CharacterClass

    def test(self, input: Consumer) -> bool:
        return self.character_class.test(input.next())


@dataclasses.dataclass(kw_only=True)
class Group(PredicateNode):
    values: str
    negate: bool = False
    allowed: typing.Set[str] = dataclasses.field(init=False, repr=False)

    def __post_init__(self):
        vs = []
        i = 0
        while i < len(self.values):
            if i + 2 < len(self.values) and self.values[i+1] == '-':
                start, end = self.values[i], self.values[i+2]
                for code in range(ord(start), ord(end) + 1):
                    vs.append(chr(code))
                i += 3
            else:
                vs.append(self.values[i])
                i += 1
        self.allowed = set(vs)

    def test(self, input: Consumer) -> bool:
        c = input.next()
        if c == "\0":
            return False
        return (c not in self.allowed) if self.negate else (c in self.allowed)


@dataclasses.dataclass(kw_only=True)
class StartAnchor(Node):
    def match(self, input: Consumer) -> bool:
        return input.start


@dataclasses.dataclass(kw_only=True)
class EndAnchor(Node):
    def match(self, input: Consumer) -> bool:
        return input.end


@dataclasses.dataclass(kw_only=True)
class Repeat(Node):
    min: int
    max: int = 0xFFFFFFFF
    child: Node = dataclasses.field(repr=False)

    def match(self, input: Consumer) -> bool:
        count = 0
        while count < self.max and self.child.match(input):
            count += 1
        return count >= self.min


@dataclasses.dataclass(kw_only=True)
class Capture(Node):
    number: int
    value: str = None
    child: Node = dataclasses.field(repr=False)

    def match(self, input: Consumer) -> bool:
        start = input.index
        if self.child.match(input):
            self.value = input.slice(start)
            return True
        return False


@dataclasses.dataclass(kw_only=True)
class Backreference(PredicateNode):
    number: int
    capture: Capture = dataclasses.field(repr=False, default=None)

    def test(self, input: Consumer) -> bool:
        # match the exact literal of the captured text
        if self.capture is None or self.capture.value is None:
            return False
        for ch in self.capture.value:
            if input.next() != ch:
                return False
        return True


@dataclasses.dataclass(kw_only=True)
class And(Node):
    children: typing.List[Node] = dataclasses.field(repr=False, default_factory=list)

    def match(self, input: Consumer) -> bool:
        for node in self.children:
            if not node.match(input):
                return False
        return True


@dataclasses.dataclass(kw_only=True)
class Or(Node):
    children: typing.List[Node] = dataclasses.field(repr=False, default_factory=list)

    def match(self, input: Consumer) -> bool:
        for node in self.children:
            if node.match(input):
                return True
        return False


@dataclasses.dataclass(kw_only=True)
class Final(Node):
    name: str = "final"
    def match(self, input: Consumer) -> bool:
        return True


def build(pattern: str) -> typing.Tuple[Node, typing.List[Capture]]:
    captures: typing.List[Capture] = []
    capture_number = 0
    index = 0

    def consume() -> str:
        nonlocal index
        if index >= len(pattern):
            return "\0"
        ch = pattern[index]
        index += 1
        return ch

    def parse() -> Node:
        nonlocal capture_number
        ors: typing.List[Or] = []
        nodes: typing.List[Node] = []

        def append_repeat(min_: int, max_: int = None):
            if max_ is None:
                max_ = Repeat.max
            last = nodes.pop()
            if isinstance(last, Literal) and len(last.value) > 1:
                prefix, suffix = last.value[:-1], last.value[-1]
                nodes.append(Literal(value=prefix))
                last = Literal(value=suffix)
            nodes.append(Repeat(child=last, min=min_, max=max_))

        # helper to peek at the next pattern character
        def peek_pat() -> str:
            return pattern[index] if index < len(pattern) else "\0"

        while True:
            ch = consume()
            if ch == "\0" or ch == ")":
                break

            if ch == "\\":
                k = consume()
                if k.isdigit():
                    node = Backreference(number=int(k), capture=None)
                elif k in {c.value for c in CharacterClass}:
                    node = Range(character_class=CharacterClass.of(k))
                else:
                    node = Literal(value=k)
                nodes.append(node)

            elif ch == "^":
                nodes.append(StartAnchor())

            elif ch == "$":
                nodes.append(EndAnchor())

            elif ch == ".":
                nodes.append(Wildcard())

            elif ch == "+":
                append_repeat(min_=1)

            elif ch == "?":
                append_repeat(min_=0, max_=1)

            elif ch == "|":
                ors.append(And(children=list(nodes)) if len(nodes) > 1 else nodes[0])
                nodes.clear()

            elif ch == "[":
                chars: typing.List[str] = []
                neg = False

                # consume until closing bracket
                while True:
                    c2 = consume()
                    if c2 == "\0" or c2 == "]":
                        break
                    # leading ^ means negation
                    if c2 == "^" and not chars:
                        neg = True
                        continue

                    # backslash‐escape inside class
                    if c2 == "\\":
                        esc = consume()
                        if esc in {c.value for c in CharacterClass}:
                            klass = CharacterClass.of(esc)
                            if klass is CharacterClass.DIGITS:
                                chars.extend(chr(x) for x in range(ord("0"), ord("9") + 1))
                            else:
                                # WORDS = digits + letters + underscore
                                chars.extend(chr(x) for x in range(ord("0"), ord("9") + 1))
                                chars.extend(chr(x) for x in range(ord("A"), ord("Z") + 1))
                                chars.extend(chr(x) for x in range(ord("a"), ord("z") + 1))
                                chars.append("_")
                        else:
                            # any other \X is literal X
                            chars.append(esc)
                    # range a-z
                    elif c2 == "-" and chars and peek_pat() != "]":
                        start = chars.pop()
                        end = consume()
                        for code in range(ord(start), ord(end) + 1):
                            chars.append(chr(code))
                    else:
                        chars.append(c2)

                # build a Group node from the expanded set
                nodes.append(Group(values="".join(chars), negate=neg))

            elif ch == "(":
                capture_number += 1
                sub = parse()
                cap = Capture(number=capture_number, child=sub)
                captures.append(cap)
                nodes.append(cap)

            else:
                # literal accumulation
                if nodes and isinstance(nodes[-1], Literal):
                    nodes[-1].value += ch
                else:
                    nodes.append(Literal(value=ch))

        # combine ORs if any
        if ors:
            if nodes:
                ors.append(And(children=list(nodes)))
            return Or(children=ors)

        return And(children=list(nodes)) if len(nodes) > 1 else nodes[0]

    # build full graph
    root = And(name="start", children=[parse(), Final()])

    # wire up backreferences and name nodes
    capture_map = {cap.number: cap for cap in captures}
    counter = 0

    def post(nodes: typing.List[Node]):
        nonlocal counter
        for n in nodes:
            counter += 1
            n.name = f"q{counter}"
            if isinstance(n, Backreference):
                n.capture = capture_map[n.number]
            if hasattr(n, "children"):
                post(getattr(n, "children"))
            if hasattr(n, "child"):
                post([getattr(n, "child")])

    post(root.children)
    return root, captures


def match(root: Node, text: str) -> bool:
    inp = Consumer(text)
    while not inp.end:
        inp.mark()
        if root.match(inp):
            inp.pop()
            return True
        inp.reset()
        inp.next()
    return False


def main():
    if len(sys.argv) != 3 or sys.argv[1] != "-E":
        print(f"Usage: {sys.argv[0]} -E PATTERN", file=sys.stderr)
        sys.exit(1)

    pattern = sys.argv[2]
    root, captures = build(pattern)

    found = False
    for raw in sys.stdin:
        line = raw.rstrip("\n")
        if match(root, line):
            found = True
            print(line)
            for i, cap in enumerate(captures, start=1):
                print(f"group[{i}] = `{cap.value}`")
    sys.exit(0 if found else 1)


if __name__ == "__main__":
    main()
