#!/usr/bin/env python3
import os
import sys
import tempfile
import shutil

# use simple absolute imports so you can run `python main.py`
import libc
import hub

def usage():
    print(f"Usage: {sys.argv[0]} run IMAGE COMMAND [ARGS...]", file=sys.stderr)
    sys.exit(1)

def main():
    # 1) validate args
    if len(sys.argv) < 4 or sys.argv[1] != "run":
        usage()

    _, cmd, image, *argv = sys.argv
    program_path = argv[0]

    # 2) pull image into a temp dir
    with tempfile.TemporaryDirectory() as rootfs:
        hub.pull(image, rootfs)

        # 3) copy the program in, if it's not already in the image
        #    strip leading slash so we don't end up with //bin/sh
        container_prog = program_path.lstrip("/")
        dest_dir = os.path.join(rootfs, os.path.dirname(container_prog))
        os.makedirs(dest_dir, exist_ok=True)
        shutil.copy2(program_path, dest_dir)

        # 4) enter new PID + mount namespaces
        flags = libc.CLONE_NEWPID | libc.CLONE_NEWNS
        libc.unshare(flags)

        pid = os.fork()
        if pid == 0:
            # child in new PID namespace
            os.chroot(rootfs)
            os.chdir("/")

            # mount proc inside the new namespace so /proc appears
            libc.mount(b"proc", b"/proc", b"proc", 0, b"")

            # finally exec the user’s command
            os.execvp(program_path, argv)

        # parent waits and exits with the child’s status
        _, status = os.waitpid(pid, 0)
        exit_code = os.WEXITSTATUS(status)
        sys.exit(exit_code)

if __name__ == "__main__":
    main()
