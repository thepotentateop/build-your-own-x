import os
import ctypes
from ctypes import c_char_p, c_ulong

# load libc
dll = ctypes.CDLL("libc.so.6", use_errno=True)

# flags for unshare()
CLONE_NEWPID = 0x20000000
CLONE_NEWNS  = 0x00020000  # new mount namespace

# declare unshare()
dll.unshare.argtypes = [ctypes.c_int]
dll.unshare.restype  = ctypes.c_int

# declare mount()
dll.mount.argtypes = [c_char_p, c_char_p, c_char_p, c_ulong, c_char_p]
dll.mount.restype  = ctypes.c_int

def unshare(flags: int):
    if dll.unshare(flags) != 0:
        errno = ctypes.get_errno()
        raise OSError(errno, f"unshare failed: {os.strerror(errno)}")

def mount(source: bytes, target: bytes, fs_type: bytes,
          flags: int = 0, data: bytes = b""):
    if dll.mount(source, target, fs_type, flags, data) != 0:
        errno = ctypes.get_errno()
        raise OSError(errno, f"mount failed: {os.strerror(errno)}")
