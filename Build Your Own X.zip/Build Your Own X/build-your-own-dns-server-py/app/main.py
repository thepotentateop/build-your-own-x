import socket
from app.dnsmessage import create_dns_response

def main():
    print("Simple Python DNS server listening on 127.0.0.1:2053")
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.bind(("127.0.0.1", 2053))

    while True:
        try:
            data, client = udp_socket.recvfrom(512)
            print(f"→ Received {len(data)} bytes from {client}")

            response = create_dns_response(data, answer_ip="8.8.8.8")
            udp_socket.sendto(response, client)
            print(f"← Sent {len(response)}-byte response")

        except KeyboardInterrupt:
            print("Shutting down.")
            break
        except Exception as e:
            print("Error:", e)
            break

if __name__ == "__main__":
    main()
