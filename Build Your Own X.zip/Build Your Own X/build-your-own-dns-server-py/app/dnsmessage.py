import socket
import struct
from dataclasses import dataclass, field
from typing import List, Tuple

# Constants for DNS types and classes
@dataclass
class DNSQuestion:
    qname: bytes
    qtype: int
    qclass: int

    def to_bytes(self) -> bytes:
        return self.qname + struct.pack("!HH", self.qtype, self.qclass)

@dataclass
class DNSResource:
    name: bytes
    type_: int
    class_: int
    ttl: int
    rdlength: int
    rdata: bytes

    def to_bytes(self) -> bytes:
        # name here can be a pointer (e.g. b'\xc0\x0c') or a full qname
        return (
            self.name
            + struct.pack("!HHIH", self.type_, self.class_, self.ttl, self.rdlength)
            + self.rdata
        )

@dataclass
class DNSHeader:
    id: int = 0
    qr: int = 0
    opcode: int = 0
    aa: int = 0
    tc: int = 0
    rd: int = 0
    ra: int = 0
    z: int = 0
    rcode: int = 0
    qdcount: int = 0
    ancount: int = 0
    nscount: int = 0
    arcount: int = 0

    def to_bytes(self) -> bytes:
        flags = (
            (self.qr << 15)
            | (self.opcode << 11)
            | (self.aa << 10)
            | (self.tc << 9)
            | (self.rd << 8)
            | (self.ra << 7)
            | (self.z << 4)
            | self.rcode
        )
        return struct.pack(
            "!HHHHHH",
            self.id,
            flags,
            self.qdcount,
            self.ancount,
            self.nscount,
            self.arcount,
        )

@dataclass
class DNSMessage:
    header: DNSHeader
    question: List[DNSQuestion]
    resource: List[DNSResource] = field(default_factory=list)

    def to_bytes(self) -> bytes:
        return (
            self.header.to_bytes()
            + b"".join(q.to_bytes() for q in self.question)
            + b"".join(r.to_bytes() for r in self.resource)
        )

def _parse_question(data: bytes) -> Tuple[bytes, int, int, int]:
    """
    Returns (transaction_id, rd_flag, DNSQuestion)
    """
    # Transaction ID
    tid = struct.unpack("!H", data[:2])[0]
    # Flags; extract RD bit
    flags = struct.unpack("!H", data[2:4])[0]
    rd = (flags >> 8) & 1

    # Skip header (12 bytes), now at the start of QNAME
    idx = 12
    labels = []
    while True:
        length = data[idx]
        idx += 1
        if length == 0:
            break
        labels.append(data[idx - 1 : idx + length])
        idx += length
    qname = b"".join(labels) + b"\x00"

    # QTYPE and QCLASS
    qtype, qclass = struct.unpack("!HH", data[idx : idx + 4])
    return tid, rd, DNSQuestion(qname=qname, qtype=qtype, qclass=qclass)

def create_dns_response(request_data: bytes, answer_ip: str = "8.8.8.8") -> bytes:
    tid, rd, question = _parse_question(request_data)

    # Build header
    header = DNSHeader(
        id=tid,
        qr=1,         # response
        opcode=0,
        aa=1,         # authoritative
        tc=0,
        rd=rd,        # copy Recursion Desired
        ra=0,         # recursion not available
        z=0,
        rcode=0,
        qdcount=1,
        ancount=1,
        nscount=0,
        arcount=0,
    )

    # Answer section: pointer back to question at offset 12
    pointer_to_qname = b"\xc0\x0c"
    rdata = socket.inet_aton(answer_ip)
    resource = DNSResource(
        name=pointer_to_qname,
        type_=question.qtype,
        class_=question.qclass,
        ttl=60,
        rdlength=len(rdata),
        rdata=rdata,
    )

    msg = DNSMessage(header=header, question=[question], resource=[resource])
    return msg.to_bytes()
